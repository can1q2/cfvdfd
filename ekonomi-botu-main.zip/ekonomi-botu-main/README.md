# ekonomi-botu
Basit bir ekonomi botudur. Eğlenmek amaçlı yapılmıştır çalınıp satmak/sunmak yasaktır!
Aksi taktirde ceza-i işlem yaptırılıcaktır!

Botu çalıştırmak kolaydır sadece 
```bash
npm install
```
Sornrada ise Bu aşşağıdaki boşlukları doldurmak. Sorun vs olursa ✩ Dens#0709'a ulaşabilirsiniz.
```json
{
  "prefix": ".",
  "token": "TOKENİNİZ",
  "sahipID": "SAHİP_ID",
  "botStatus": "BOT_STATUS",
  "paraBirimi": "TL/EURO",
  "altYazi": "EMBEDLERIN_ALTINDAKI_YAZI",
  "maxParaVerme": {
    "calisma": "MAX_CALISMA_PARASI/ORNEK: 5000",
    "calismaVIP": "VIP_ICIN_MAX_CALISMA_PARASI/ORNEK: 5000",
    "dilencilik": "MAX_DILENCI_PARASI/ORNEK: 5000",
    "dilencilikVIP": "VIP_ICIN_MAX_DILENCI_PARASI/ORNEK: 5000",
    "gunluk": "MAX_GUNLUK_PARASI/ORNEK: 5000",
    "gunlukVIP": "VIP_ICIN_MAX_GUNLUK_PARASI/ORNEK: 5000"
  },
  "satisFiyat": {
    "nike": "NIKE_AYAKKABI_SATMA_FIYATI/ORNEK: 1000",
    "araba": "ARABA_SATMA_FIYATI/ORNEK: 1000",
    "ev": "EV_SATMA_FIYATI/ORNEK: 1000",
    "vip": "VIP_SATMA_FIYATI/ORNEK: 1000"
  },
  "satınalFiyat": {
    "nike": "NIKE_SATINALMA_FIYATI/ORNEK: 1000",
    "araba": "ARABA_SATINALMA_FIYATI/ORNEK: 1000",
    "ev": "EV_SATINALMA_FIYATI/ORNEK: 1000",
    "vip": "VIP_SATINALMA_FIYATI/ORNEK: 1000"
  }
}
```

## License
[MIT](https://choosealicense.com/licenses/mit/)
